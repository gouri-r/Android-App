package com.example.ideathonfinal;

import java.util.Date;

public class PartyNames {
    String name;
    String caseno;
    String ndate;
    String judge;
    String court;
    String phnno;
    String email;
    String notes;

    public PartyNames()
    {

    }

    public PartyNames(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
