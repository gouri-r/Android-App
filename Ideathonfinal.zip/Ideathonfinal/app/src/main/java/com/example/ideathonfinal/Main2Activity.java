package com.example.ideathonfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Main2Activity extends AppCompatActivity {


    DatabaseReference database = MainActivity.database;

    String name;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        name = getIntent().getStringExtra("NAME");
        id = getIntent().getStringExtra("ID");
        TextView t = findViewById(R.id.textView2);
        Button b = findViewById(R.id.btndetails);
        t.setText(name);
        final EditText e1 = findViewById(R.id.caseno);
        final EditText e2 = findViewById(R.id.nextdate);
        final EditText e3 = findViewById(R.id.judgename);
        final EditText e4 = findViewById(R.id.court);
        final EditText e5 = findViewById(R.id.partyphno);
        final EditText e6 = findViewById(R.id.pemail);
        final EditText e7 = findViewById(R.id.notes);
        final PartyNames p = new PartyNames(name);
        /*p.caseno = e1.getText().toString();
        database.child(id).setValue(p);*/
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p.caseno = e1.getText().toString();
                //p.ndate = e2.getText().toString();
                p.ndate = e2.getText().toString();
                p.judge = e3.getText().toString();
                p.court = e4.getText().toString();
                p.phnno = e5.getText().toString();
                p.email = e6.getText().toString();
                p.notes = e7.getText().toString();
                database.child(id).setValue(p);
                Intent i = new Intent(Main2Activity.this,Main3Activity.class);
                i.putExtra("IDD",id);

            }
        });



    }

}
