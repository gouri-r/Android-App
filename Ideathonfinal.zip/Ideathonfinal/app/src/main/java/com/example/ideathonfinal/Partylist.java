package com.example.ideathonfinal;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.ideathonfinal.PartyNames;
import com.example.ideathonfinal.R;

import java.util.List;

class Partylist extends ArrayAdapter<PartyNames> {

    private Activity context;
    private List<PartyNames> namesList;

    public Partylist(Activity context, List<PartyNames> namesList){
        super(context, R.layout.list_layout, namesList);
        this.context=context;
        this.namesList=namesList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);
        TextView textViewName =(TextView) listViewItem.findViewById(R.id.textView);

        PartyNames partynames= namesList.get(position);
        textViewName.setText(partynames.name);

        return listViewItem;
    }
}



